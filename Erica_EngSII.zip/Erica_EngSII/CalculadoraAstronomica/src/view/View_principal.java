
package view;
import view.View2_historico;
import calc.ControllerAstro;
import calc.ControllerAstro;
import calc.ModelAstro;

import static com.sun.org.apache.xalan.internal.lib.ExsltDatetime.date;

import java.awt.EventQueue;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

//import calc.ModelAstro;
import javax.swing.JOptionPane;
import static com.sun.org.apache.xalan.internal.lib.ExsltDatetime.date;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.Action;
import javax.swing.JButton;
import static com.sun.org.apache.xalan.internal.lib.ExsltDatetime.date;
import static com.sun.org.apache.xalan.internal.lib.ExsltDatetime.date;

public class View_principal extends javax.swing.JFrame {

    View2_historico historico;  

   ControllerAstro calc;
   private final ModelAstro calc1;
    private final ModelAstro calc2;  
    private int lbl_Ua;

Locale locale = new Locale("pt","BR");
    Object btn_Km;
    private Object txt_Anosluz;
    public Object Teste;
   
 
    
   
    public View_principal() {
        initComponents();
        //lc = new ControllerAstro();
        calc1 =new ModelAstro();
        calc2=new ModelAstro();
        
    }

    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txt_AnosLuz = new javax.swing.JTextField();
        lbl_titulo = new javax.swing.JLabel();
        btn_KM = new javax.swing.JButton();
        lbl_conversao = new javax.swing.JLabel();
        btnMI = new javax.swing.JButton();
        btn_MT = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        tab_entrada = new javax.swing.JLabel();
        tab_conversao = new javax.swing.JLabel();
        tab_Ua = new javax.swing.JLabel();
        tab_data = new javax.swing.JLabel();
        btn_Hitorico = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        label_background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        txt_AnosLuz.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_AnosLuzActionPerformed(evt);
            }
        });
        txt_AnosLuz.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_AnosLuzKeyPressed(evt);
            }
        });
        getContentPane().add(txt_AnosLuz);
        txt_AnosLuz.setBounds(260, 70, 110, 37);

        lbl_titulo.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        lbl_titulo.setForeground(new java.awt.Color(255, 255, 255));
        lbl_titulo.setText("\"Digite A quantidade em Light-year\"");
        getContentPane().add(lbl_titulo);
        lbl_titulo.setBounds(170, 30, 320, 22);

        btn_KM.setBackground(new java.awt.Color(238, 238, 205));
        btn_KM.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        btn_KM.setForeground(new java.awt.Color(255, 102, 0));
        btn_KM.setText("KM");
        btn_KM.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_KMMouseClicked(evt);
            }
        });
        btn_KM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_KMActionPerformed(evt);
            }
        });
        getContentPane().add(btn_KM);
        btn_KM.setBounds(160, 160, 80, 40);

        lbl_conversao.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        lbl_conversao.setForeground(new java.awt.Color(255, 255, 255));
        lbl_conversao.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_conversao.setText("0");
        getContentPane().add(lbl_conversao);
        lbl_conversao.setBounds(200, 230, 210, 30);

        btnMI.setBackground(new java.awt.Color(255, 255, 204));
        btnMI.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        btnMI.setForeground(new java.awt.Color(255, 102, 0));
        btnMI.setText("Mi");
        btnMI.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnMIMouseClicked(evt);
            }
        });
        btnMI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMIActionPerformed(evt);
            }
        });
        getContentPane().add(btnMI);
        btnMI.setBounds(270, 160, 80, 40);

        btn_MT.setBackground(new java.awt.Color(255, 255, 204));
        btn_MT.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        btn_MT.setForeground(new java.awt.Color(255, 51, 0));
        btn_MT.setText("m");
        btn_MT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_MTMouseClicked(evt);
            }
        });
        btn_MT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_MTActionPerformed(evt);
            }
        });
        getContentPane().add(btn_MT);
        btn_MT.setBounds(370, 160, 80, 40);

        jLabel1.setBackground(new java.awt.Color(51, 153, 255));
        jLabel1.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("  Entrada LY           Conversao                  Unidade Astrononica                  Data hora");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 270, 620, 30);

        tab_entrada.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        tab_entrada.setForeground(new java.awt.Color(255, 255, 255));
        tab_entrada.setText("0");
        getContentPane().add(tab_entrada);
        tab_entrada.setBounds(30, 310, 60, 20);

        tab_conversao.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        tab_conversao.setForeground(new java.awt.Color(255, 255, 255));
        tab_conversao.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tab_conversao.setText("0");
        getContentPane().add(tab_conversao);
        tab_conversao.setBounds(120, 310, 80, 20);

        tab_Ua.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        tab_Ua.setForeground(new java.awt.Color(255, 255, 255));
        tab_Ua.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tab_Ua.setText("0");
        getContentPane().add(tab_Ua);
        tab_Ua.setBounds(260, 310, 120, 18);

        tab_data.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        tab_data.setForeground(new java.awt.Color(255, 255, 255));
        tab_data.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tab_data.setText("0");
        getContentPane().add(tab_data);
        tab_data.setBounds(400, 310, 200, 18);

        btn_Hitorico.setBackground(new java.awt.Color(255, 255, 204));
        btn_Hitorico.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        btn_Hitorico.setForeground(new java.awt.Color(255, 102, 0));
        btn_Hitorico.setText("HISTORICO");
        btn_Hitorico.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_HitoricoMouseClicked(evt);
            }
        });
        btn_Hitorico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_HitoricoActionPerformed(evt);
            }
        });
        getContentPane().add(btn_Hitorico);
        btn_Hitorico.setBounds(520, 359, 100, 21);

        jLabel2.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Escolha a conversao desejada");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(210, 120, 230, 18);

        label_background.setBackground(new java.awt.Color(200, 200, 200));
        label_background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/calc/imagens/bt2.png"))); // NOI18N
        label_background.setMaximumSize(new java.awt.Dimension(1000, 1000));
        getContentPane().add(label_background);
        label_background.setBounds(0, 0, 650, 390);

        setBounds(0, 0, 667, 427);
    }// </editor-fold>//GEN-END:initComponents

    private void txt_AnosLuzActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_AnosLuzActionPerformed
    
      //txt_AnosLuz.addKeyListener(new java.awt.Event(KeyListner();
      
        
        /*
        String valor= "1 2 3 4 5 6 7 8 9 0 , " ;
       if(txt_AnosLuz.getText() != valor){
        
            JOptionPane.showMessageDialog(null," Digitar SOMENTE Numeros!");
        
    }
        */
    }//GEN-LAST:event_txt_AnosLuzActionPerformed

    private void btn_KMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_KMActionPerformed
         
             
        
        lbl_conversao.setText(String.valueOf(calc1.Kilometros(Double.parseDouble(txt_AnosLuz.getText()))));
        
         if (txt_AnosLuz.getText().equals("") ){
            double unidade_astro=0;
         }
    
            else{
             
             double unidade_astro= Double.parseDouble(txt_AnosLuz.getText());
            
                 tab_Ua(calc1.Ua_km(unidade_astro));
                 
         }     
        
         
              
    }//GEN-LAST:event_btn_KMActionPerformed

    private void btnMIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMIActionPerformed
         
        lbl_conversao.setText(String.valueOf(calc1.Milhas(Double.parseDouble(txt_AnosLuz.getText()))));
        
         if (txt_AnosLuz.getText().equals("") ){
            double unidade_astro=0;
         }
    
            else{
             
             double unidade_astro= Double.parseDouble(txt_AnosLuz.getText());
             
                 lbl_Ua(calc1.Ua_Mi(unidade_astro));
                 
         
         }
         
    }//GEN-LAST:event_btnMIActionPerformed

    private void btn_MTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_MTActionPerformed
       lbl_conversao.setText(String.valueOf(calc1.Metros(Double.parseDouble(txt_AnosLuz.getText()))));
        
         if (txt_AnosLuz.getText().equals("") ){
            double unidade_astro=0;
         }
    
            else{
             
             double unidade_astro= Double.parseDouble(txt_AnosLuz.getText());
             
                 lbl_Ua(calc1.Ua_Mt(unidade_astro));
                 
                                               
                    }
    }//GEN-LAST:event_btn_MTActionPerformed

    private void btn_KMMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_KMMouseClicked
       
    
     //para mostrar a entrada no textbox
     tab_entrada.setText(String.valueOf((Double.parseDouble(txt_AnosLuz.getText()))));
     
      //para adicionar data e hora no ladel data
     SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.sss");

     Date dt =  new Date();
     tab_data.setText(new Date().toString());
       //***********************************************************
       //para saida de dados nos labels para KILOMETROS
      tab_conversao.setText(String.valueOf(calc1.Kilometros(Double.parseDouble(txt_AnosLuz.getText()))));
      tab_Ua.setText(String.valueOf(calc1.Ua_km(Double.parseDouble(txt_AnosLuz.getText()))));
      
              
        
    }//GEN-LAST:event_btn_KMMouseClicked

    private void btnMIMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnMIMouseClicked
        // TODO add your handling code here:
        tab_entrada.setText(String.valueOf((Double.parseDouble(txt_AnosLuz.getText()))));
     
      //para adicionar data e hora no ladel data
     SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.sss");

     Date dt =  new Date();
     tab_data.setText(new Date().toString());
        


     //para saida de dados nos labels para MILHAS 
      tab_conversao.setText(String.valueOf(calc1.Milhas(Double.parseDouble(txt_AnosLuz.getText()))));
      tab_Ua.setText(String.valueOf(calc1.Ua_Mi(Double.parseDouble(txt_AnosLuz.getText()))));

        
        
    }//GEN-LAST:event_btnMIMouseClicked

    private void btn_MTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_MTMouseClicked
        // TODO add your handling code here:
        
     
        tab_entrada.setText(String.valueOf((Double.parseDouble(txt_AnosLuz.getText()))));
     
      //para adicionar data e hora no ladel data
     SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.sss");

     Date dt =  new Date();
     tab_data.setText(new Date().toString());
        
       
     //para saida de dados nos labels para MILHAS 
      tab_conversao.setText(String.valueOf(calc1.Metros(Double.parseDouble(txt_AnosLuz.getText()))));
      tab_Ua.setText(String.valueOf(calc1.Ua_Mt(Double.parseDouble(txt_AnosLuz.getText()))));
        
    }//GEN-LAST:event_btn_MTMouseClicked

    private void btn_HitoricoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_HitoricoActionPerformed
       
        
        //video
        if(historico == null){
           historico = new View2_historico();
            historico.setVisible(true);
            historico.Entrada(txt_AnosLuz.getText());
            historico.Conversao(tab_conversao.getText());
            historico.Uni_Astro(tab_Ua.getText());
            historico.Data(tab_data.getText());
        }
        else{
            historico.setVisible(true);
            //dispose();
            historico.setState(historico.NORMAL);
            historico.Entrada(txt_AnosLuz.getText());
        }
        
        
        
        
        
        
        
        
    }//GEN-LAST:event_btn_HitoricoActionPerformed

    private void btn_HitoricoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_HitoricoMouseClicked
        // TODO add your handling code here:
         //View2 historico = new View2();
        //historico.setVisible(true);
        
      // View2_historico t = new View2_historico();
       // t.setVisible(true);
        
        
        
        
    }//GEN-LAST:event_btn_HitoricoMouseClicked

    private void txt_AnosLuzKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_AnosLuzKeyPressed
        // TODO add your handling code here:
        
        
    }//GEN-LAST:event_txt_AnosLuzKeyPressed
    
    
    
   

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(View_principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(View_principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(View_principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(View_principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        //public static void main(String args[]){
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new View_principal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnMI;
    private javax.swing.JButton btn_Hitorico;
    private javax.swing.JButton btn_KM;
    private javax.swing.JButton btn_MT;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel label_background;
    private javax.swing.JLabel lbl_conversao;
    private javax.swing.JLabel lbl_titulo;
    private javax.swing.JLabel tab_Ua;
    private javax.swing.JLabel tab_conversao;
    private javax.swing.JLabel tab_data;
    private javax.swing.JLabel tab_entrada;
    private javax.swing.JTextField txt_AnosLuz;
    // End of variables declaration//GEN-END:variables

    private void lbl_Ua(double Ua_km) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void lbl_Ua_mi(double Ua_Mi) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void lbl_UA(double Ua_Mi) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void tab_Ua(double Ua_km) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public void TextoEntrada(String texto){
        
        txt_AnosLuz.setText(texto);
        
    }
    
    

    /**
     * @return the txt_Anosluz
     */
    public Object getTxt_Anosluz() {
        return txt_Anosluz;
    }

    /**
     * @param txt_Anosluz the txt_Anosluz to set
     */
    public void setTxt_Anosluz(Object txt_Anosluz) {
        this.txt_Anosluz = txt_Anosluz;
    }
}

