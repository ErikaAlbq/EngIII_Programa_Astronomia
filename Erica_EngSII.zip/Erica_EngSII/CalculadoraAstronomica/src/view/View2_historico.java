/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import calc.ModelAstro;
import java.awt.HeadlessException;
import javax.swing.JButton;
import javax.swing.JLabel;

/**
 *
 * @author Convidado
 */
public class View2_historico extends javax.swing.JFrame {

    
    View_principal view =new View_principal();
    private  ModelAstro calc2;

    
    public View2_historico() {
        initComponents();
         
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        titulo = new javax.swing.JLabel();
        btn_limpar_H = new javax.swing.JButton();
        btn_voltar_H = new javax.swing.JButton();
        lbl_H_entrada = new javax.swing.JLabel();
        lbl_H_conversao = new javax.swing.JLabel();
        lbl_H_Ua = new javax.swing.JLabel();
        lbl_H_data = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel2.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Entrada Ly          Conversao              Unidade Astro           Data e Hora");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(0, 70, 500, 30);

        titulo.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        titulo.setForeground(new java.awt.Color(255, 255, 255));
        titulo.setText("HISTORICO");
        getContentPane().add(titulo);
        titulo.setBounds(220, 30, 90, 30);

        btn_limpar_H.setText("Limpar");
        btn_limpar_H.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_limpar_HActionPerformed(evt);
            }
        });
        getContentPane().add(btn_limpar_H);
        btn_limpar_H.setBounds(130, 410, 80, 30);

        btn_voltar_H.setText("Voltar");
        btn_voltar_H.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_voltar_HActionPerformed(evt);
            }
        });
        getContentPane().add(btn_voltar_H);
        btn_voltar_H.setBounds(270, 410, 70, 30);

        lbl_H_entrada.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        lbl_H_entrada.setForeground(new java.awt.Color(255, 255, 255));
        lbl_H_entrada.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_H_entrada.setText("0");
        lbl_H_entrada.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                lbl_H_entradaAncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        getContentPane().add(lbl_H_entrada);
        lbl_H_entrada.setBounds(12, 108, 70, 20);

        lbl_H_conversao.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        lbl_H_conversao.setForeground(new java.awt.Color(255, 255, 255));
        lbl_H_conversao.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_H_conversao.setText("0");
        getContentPane().add(lbl_H_conversao);
        lbl_H_conversao.setBounds(100, 110, 100, 20);

        lbl_H_Ua.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        lbl_H_Ua.setForeground(new java.awt.Color(255, 255, 255));
        lbl_H_Ua.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_H_Ua.setText("0");
        getContentPane().add(lbl_H_Ua);
        lbl_H_Ua.setBounds(230, 110, 90, 20);

        lbl_H_data.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        lbl_H_data.setForeground(new java.awt.Color(255, 255, 255));
        lbl_H_data.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_H_data.setText("0");
        getContentPane().add(lbl_H_data);
        lbl_H_data.setBounds(340, 110, 160, 14);

        jLabel1.setFont(new java.awt.Font("Trebuchet MS", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/calc/imagens/frame2.png"))); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 520, 500);

        setBounds(0, 0, 533, 541);
    }// </editor-fold>//GEN-END:initComponents

    private void lbl_H_entradaAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_lbl_H_entradaAncestorAdded
        // TODO add your handling code here:

    }//GEN-LAST:event_lbl_H_entradaAncestorAdded

    private void btn_voltar_HActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_voltar_HActionPerformed
        // TODO add your handling code here:
        //View_principal voltar= new View_principal ();
      //  voltar.setVisible(true);
        
           
        
    }//GEN-LAST:event_btn_voltar_HActionPerformed

    private void btn_limpar_HActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_limpar_HActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_limpar_HActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        //(calc1.Milhas(Double.parseDouble(txt_AnosLuz.getText()))));
         // ModelAstro calc1 =new ModelAstro();
          //ControllerAstro controller =new  ControllerAstro();
        
        
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(View2_historico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(View2_historico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(View2_historico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(View2_historico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new View2_historico().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_limpar_H;
    private javax.swing.JButton btn_voltar_H;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel lbl_H_Ua;
    private javax.swing.JLabel lbl_H_conversao;
    private javax.swing.JLabel lbl_H_data;
    private javax.swing.JLabel lbl_H_entrada;
    private javax.swing.JLabel titulo;
    // End of variables declaration//GEN-END:variables

   public void Entrada(String entrada){
       lbl_H_entrada.setText(entrada);
       
   }

   public void Conversao(String conversao){
       lbl_H_conversao.setText(conversao);
       
   }
    public void Uni_Astro(String Ua){
       lbl_H_Ua.setText(Ua);
       
   }
    public void Data(String data){
       lbl_H_data.setText(data);
       
   }
    
    
    
}
