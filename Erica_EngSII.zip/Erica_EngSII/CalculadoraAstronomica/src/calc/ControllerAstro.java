
package calc;
import view.View_principal;
import calc.ModelAstro;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.text.MaskFormatter;

public class ControllerAstro implements ActionListener {

    private Object view;
    private Object model;
    private Object txt_Anos_luz;
    private  double texto_entrada;
    
    View_principal principal =new View_principal();
 
     
     public ControllerAstro(View_principal view , ModelAstro model   ){
       
         
    model = new  ModelAstro();
   
   
    this.view=view;
    this.model=model;
    
    
     }

    ControllerAstro(){
        
    }
    
   //**************************************************************          
   public void actionPerformed(ActionEvent e, Object txt_AnosLuz ){
       
      //para dar controle as entradas de de numero do textfild
       /*
       this.txt_Anos_luz= Double.parseDouble((String) this.principal.getTxt_Anosluz());
       String valor= "1 2 3 4 5 6 7 8 9 0 , " ;
       if(txt_AnosLuz != valor){
        
            JOptionPane.showMessageDialog(null," Digitar SOMENTE Numeros!");
            //txt_AnosLuz.grabFocus();
        }
     
  
  */
 
       
       
      
}
    private String txt_AnosLuz() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
       
   
   
 
          
         
     
       

    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
       
   
   }
  
  
			 
  

    
    
      
  
   
       
    

   

   
    
    
