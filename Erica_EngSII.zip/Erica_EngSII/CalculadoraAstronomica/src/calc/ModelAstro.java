
 
package calc;
import calc.ControllerAstro;
/**
 *
 * @author Convidado
 */
public class ModelAstro {
    
    // atributos para uso das formulas 
    
   
    private double anos_luz=0;
    //private double resultado;
    
    
    double velocidadeluz = 300.000;
    double seg_anos_km= 3.154;
    double conversao_mil_km = Math.pow(10,12);
    double f =  seg_anos_km*conversao_mil_km;
    double Formula_anosluz = (f *  velocidadeluz);
    //**************************************************************
    
    //Para milhas
    double uni_milhas= 5.879;
    double conversao_mil_milhas = Math.pow(10,13);
    double formula_anosluz_milhas =  uni_milhas*conversao_mil_milhas;
    //**************************************************************
    //Para Metros
     double conversao_mil_metros = Math.pow(10,15);
     double M =  seg_anos_km*conversao_mil_metros;
     double Formula_anosluz_metros = M *  velocidadeluz;// =~9.462
     
     //atributos para unidade astronimica
     
     double UA_milhas = 1.076;
     double conversao_mil_UA_milhas = Math.pow(10, -8);
     double Formula_Mi_UA=(UA_milhas * conversao_mil_UA_milhas);// corresponde a 1km em 
    
    
   double UA_Metros = 6.685;
   double conversao_mil_UA_metros = Math.pow(10, -12);
   double Formula_Mt_Ua=(UA_Metros * conversao_mil_UA_metros);
    
    
    
    
//metodo Unidade Astronomica para  Kilometros
    double UA = 6.685;
    double conversao_mil_UA = Math.pow(10, -12);
    double Formula_Km_Ua=(UA * conversao_mil_km);
    
    
     public double getAnosluz(){
        return getAnos_luz();
    }
    public void setAnosLuz(double anosluz){
        this.setAnos_luz(anosluz);
    }
     
    
    public double Kilometros( double anos_luz){
        double Conversao_km;
        return Conversao_km = (Formula_anosluz * anos_luz); 
    }
  
       
  //metodo conversao anos luz  para  Milhas
   public double Milhas ( double anos_luz){
          double Conversao_Mi;
         return  Conversao_Mi = (anos_luz *  formula_anosluz_milhas);// =~5.879x10^13
         
           } 
       
   //metodo conversao anos luz  para  Metros
   public double  Metros( double anos_luz){
       double Conversao_Mt;
       return Conversao_Mt= (Formula_anosluz_metros * anos_luz); 
       
   }
   
  //Formulas para UNIDADES ASTRONOMICAS 
   public double Ua_km(double anos_luz){   
        
        double km_em_UA;
        double Conversao_km = (Formula_anosluz * anos_luz); 
        return km_em_UA=(Conversao_km  * Formula_Km_Ua);
    }
    //Metodo UA pra Milhas
    
     public double Ua_Mi(double anos_luz){
      //double Conversao_km = (Formula_anosluz * anos_luz); 
      double Mi_em_UA;
      return Mi_em_UA=(anos_luz *Formula_Mi_UA );
      
     }
       public double Ua_Mt(double anos_luz){
       
     //double Conversao_km = (Formula_anosluz * anos_luz); 
     double Mt_em_UA;  
     return Mt_em_UA=(anos_luz  * Formula_Mt_Ua);  
   } 

   
    /**
     * @return the anos_luz
     */
    public double getAnos_luz() {
        return anos_luz;
    }

    /**
     * @param anos_luz the anos_luz to set
     */
    public void setAnos_luz(double anos_luz) {
        this.anos_luz = anos_luz;
    }
      
  }
  
  

   
    
   
   
    
    
   
    

       
   
    
    
    
